import "dotenv/config";
import express from "express";
  import { createServer } from "http";
  import net from "net";
  import { createExpressMiddleware } from "@trpc/server/adapters/express";
  import { registerOAuthRoutes } from "./oauth";
  import { registerStorageProxy } from "./storageProxy";
  import { appRouter } from "../routers";
  import { createContext } from "./context";
  import { serveStatic, setupVite } from "./vite";
  import multer from "multer";
  import { sdk } from "./sdk";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  
  // Rotas para o worker processar tarefas
  app.get("/api/worker/tasks", async (req, res) => {
    try {
      const workerId = req.query.worker_id as string;
      const db = await require("../db").getDb();
      if (!db) return res.status(503).json({ error: "Database unavailable" });
      
      const tasks = await db.select().from(require("../../drizzle/schema").videoTasks)
        .where((t: any) => t.status === "pending")
        .limit(5);
      
      // Marca como processando
      for (const task of tasks) {
        await db.update(require("../../drizzle/schema").videoTasks)
          .set({ status: "processing", workerId })
          .where((t: any) => t.id === task.id);
      }
      
      res.json({ tasks });
    } catch (e) {
      console.error(e);
      res.status(500).json({ error: String(e) });
    }
  });
  
  const upload = multer({ storage: multer.memoryStorage() });
  
  app.post("/api/worker/complete", upload.single("video"), async (req, res) => {
    try {
      const taskId = req.body.task_id;
      const videoFile = req.file;
      
      if (!videoFile) return res.status(400).json({ error: "No video file" });
      
      const db = await require("../db").getDb();
      if (!db) return res.status(503).json({ error: "Database unavailable" });
      
      // Salva o vídeo e atualiza a tarefa
      const videoUrl = `/videos/${taskId}.mp4`;
      await db.update(require("../../drizzle/schema").videoTasks)
        .set({ status: "completed", videoUrl })
        .where((t: any) => t.id === taskId);
      
      res.json({ success: true });
    } catch (e) {
      console.error(e);
      res.status(500).json({ error: String(e) });
    }
  });
  
  app.post("/api/worker/error", async (req, res) => {
    try {
      const { task_id, error } = req.body;
      const db = await require("../db").getDb();
      if (!db) return res.status(503).json({ error: "Database unavailable" });
      
      await db.update(require("../../drizzle/schema").videoTasks)
        .set({ status: "failed", errorMessage: error })
        .where((t: any) => t.id === task_id);
      
      res.json({ success: true });
    } catch (e) {
      console.error(e);
      res.status(500).json({ error: String(e) });
    }
  });
  
  // Health check endpoint para manter o site ativo
  app.post("/api/scheduled/health-check", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (!user.isCron) return res.status(403).json({ error: "cron-only" });
      
      // Simples health check - apenas retorna OK
      res.json({ ok: true, timestamp: new Date().toISOString() });
    } catch (e) {
      console.error("Health check error:", e);
      res.status(500).json({ error: String(e) });
    }
  });
  
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
