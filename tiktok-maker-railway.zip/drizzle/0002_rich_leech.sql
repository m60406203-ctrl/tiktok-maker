CREATE TABLE `video_history` (
	`id` varchar(64) NOT NULL,
	`user_id` int NOT NULL,
	`task_id` varchar(64) NOT NULL,
	`story` text NOT NULL,
	`voice` varchar(32) NOT NULL,
	`style` varchar(32) NOT NULL,
	`video_url` text,
	`video_size` int,
	`duration` int,
	`thumbnail` text,
	`download_count` int DEFAULT 0,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `video_history_id` PRIMARY KEY(`id`)
);
