CREATE TABLE `video_tasks` (
	`id` varchar(64) NOT NULL,
	`story` text NOT NULL,
	`voice` varchar(32) NOT NULL,
	`style` varchar(32) NOT NULL,
	`status` enum('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
	`worker_id` varchar(64),
	`video_url` text,
	`error_message` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `video_tasks_id` PRIMARY KEY(`id`)
);
