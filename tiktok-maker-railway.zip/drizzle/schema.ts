import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Tabela para gerenciar tarefas de processamento de vídeo
export const videoTasks = mysqlTable("video_tasks", {
  id: varchar("id", { length: 64 }).primaryKey(),
  story: text("story").notNull(),
  voice: varchar("voice", { length: 32 }).notNull(),
  style: varchar("style", { length: 32 }).notNull(),
  status: mysqlEnum("status", ["pending", "processing", "completed", "failed"]).default("pending").notNull(),
  workerId: varchar("worker_id", { length: 64 }),
  videoUrl: text("video_url"),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type VideoTask = typeof videoTasks.$inferSelect;
export type InsertVideoTask = typeof videoTasks.$inferInsert;

// Tabela para historico de videos processados
export const videoHistory = mysqlTable("video_history", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("user_id").notNull(),
  taskId: varchar("task_id", { length: 64 }).notNull(),
  story: text("story").notNull(),
  voice: varchar("voice", { length: 32 }).notNull(),
  style: varchar("style", { length: 32 }).notNull(),
  videoUrl: text("video_url"),
  videoSize: int("video_size"),
  duration: int("duration"),
  thumbnail: text("thumbnail"),
  downloadCount: int("download_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type VideoHistory = typeof videoHistory.$inferSelect;
export type InsertVideoHistory = typeof videoHistory.$inferInsert;