# TikMaker — Gerador de Vídeos Virais para TikTok

## Funcionalidades Planejadas

### Frontend (React + Tailwind CSS)
- [ ] Tema dark estilo TikTok: fundo preto, acentos rosa (#ff2d55) e ciano (#00f2ea)
- [ ] Tipografia Inter e grid animado no background
- [ ] Formulário de criação com textarea para história (contador de caracteres)
- [ ] Seletor de voz (Francisca, Thalita, Antonio)
- [ ] Seletor de estilo (Viral, Story Time, Mistério)
- [ ] Exemplos de histórias clicáveis (Terror, Romance, Fato Incrível, Mistério)
- [ ] Seção de dicas para vídeos virais

### Processamento e Integração
- [ ] Integração com backend Flask local via HTTP (/generate, /status, /download)
- [ ] Chave Pexels indexada no backend para busca automática de mídia
- [ ] Validação de história (mín 50 caracteres, máx 3000)

### Barra de Progresso
- [ ] Polling de status em tempo real
- [ ] Chips de etapas animados: Narração → Legendas → Mídia → Vídeo → Renderização
- [ ] Indicador visual de progresso com cores (rosa/ciano)
- [ ] Mensagens de status descritivas

### Tela de Resultado
- [ ] Mockup de celular (9:16) com preview do vídeo
- [ ] Botão de download do MP4
- [ ] Botão de criar novo vídeo (reset do formulário)
- [ ] Informações do vídeo: resolução (1080×1920), formato (MP4 H.264), orientação (9:16)

### Otimizações
- [ ] Tratamento de erros com mensagens amigáveis
- [ ] Loading states e spinners
- [ ] Responsividade mobile
- [ ] Performance: lazy loading, otimização de assets

## Progresso

### Fase 1: Setup e Tema
- [x] Projeto WebDev inicializado (web-db-user)
- [x] Configurar tema dark TikTok em index.css
- [x] Importar fonte Inter do Google Fonts
- [x] Criar componentes base (layout, card, button)

### Fase 2: Frontend Principal
- [x] Página Home com formulário
- [x] Integração com API local
- [x] Exemplos de histórias

### Fase 3: Progresso e Status
- [x] Componente de barra de progresso
- [x] Polling de status
- [x] Chips de etapas

### Fase 4: Resultado e Download
- [x] Tela de resultado com mockup
- [x] Preview de video
- [x] Download do arquivo

### Fase 5: Testes e Otimizacoes
- [x] Testes end-to-end
- [x] Correcao de bugs
- [x] Performance

### Fase 6: Deploy
- [ ] Checkpoint final
- [ ] Entrega ao usuário
