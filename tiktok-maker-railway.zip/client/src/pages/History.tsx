import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Loader2, Download, Trash2, Play, Calendar } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

interface Video {
  id: string;
  story: string;
  voice: string;
  style: string;
  videoUrl?: string;
  duration?: number;
  downloadCount: number;
  createdAt: Date;
}

export default function History() {
  const [videos, setVideos] = useState<Video[]>([]);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);

  const { data: historyData, isLoading } = trpc.videoHistory.list.useQuery();
  const deleteVideoMutation = trpc.videoHistory.delete.useMutation();

  useEffect(() => {
    if (historyData) {
      setVideos(historyData as Video[]);
    }
  }, [historyData]);

  const handleDelete = async (id: string) => {
    if (!confirm('Tem certeza que deseja deletar este vídeo?')) return;

    try {
      await deleteVideoMutation.mutateAsync({ id });
      setVideos(videos.filter(v => v.id !== id));
      toast.success('Vídeo deletado com sucesso');
    } catch (error) {
      toast.error('Erro ao deletar vídeo');
    }
  };

  const handleDownload = (videoUrl?: string) => {
    if (!videoUrl) {
      toast.error('Vídeo não disponível');
      return;
    }
    window.open(videoUrl, '_blank');
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getVoiceLabel = (voice: string) => {
    const voices: Record<string, string> = {
      francisca: 'Francisca',
      thalita: 'Thalita',
      antonio: 'Antonio',
    };
    return voices[voice] || voice;
  };

  const getStyleLabel = (style: string) => {
    const styles: Record<string, string> = {
      viral: 'Viral',
      story: 'Story Time',
      mystery: 'Mistério',
    };
    return styles[style] || style;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-pink-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Histórico de Vídeos</h1>
          <p className="text-slate-400">
            {videos.length} vídeo{videos.length !== 1 ? 's' : ''} processado{videos.length !== 1 ? 's' : ''}
          </p>
        </div>

        {videos.length === 0 ? (
          <Card className="bg-slate-800 border-slate-700 p-12 text-center">
            <p className="text-slate-400 mb-4">Nenhum vídeo processado ainda</p>
            <p className="text-slate-500 text-sm">
              Crie seu primeiro vídeo para vê-lo aqui
            </p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videos.map((video) => (
              <Card
                key={video.id}
                className="bg-slate-800 border-slate-700 overflow-hidden hover:border-pink-500 transition-colors cursor-pointer"
                onClick={() => setSelectedVideo(video)}
              >
                {/* Thumbnail / Preview */}
                <div className="aspect-video bg-slate-900 flex items-center justify-center relative group">
                  <div className="absolute inset-0 bg-gradient-to-b from-transparent to-slate-900 opacity-60" />
                  <Play className="w-12 h-12 text-pink-500 group-hover:scale-110 transition-transform" />
                </div>

                {/* Content */}
                <div className="p-4">
                  {/* Story Preview */}
                  <p className="text-white text-sm line-clamp-2 mb-3">
                    {video.story}
                  </p>

                  {/* Metadata */}
                  <div className="space-y-2 mb-4 text-xs text-slate-400">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-1 bg-slate-700 rounded">
                        {getVoiceLabel(video.voice)}
                      </span>
                      <span className="px-2 py-1 bg-slate-700 rounded">
                        {getStyleLabel(video.style)}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-500">
                      <Calendar className="w-3 h-3" />
                      {formatDate(video.createdAt)}
                    </div>
                    {video.duration && (
                      <div className="text-slate-500">
                        Duração: {Math.floor(video.duration / 60)}:{String(video.duration % 60).padStart(2, '0')}
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDownload(video.videoUrl);
                      }}
                    >
                      <Download className="w-4 h-4 mr-1" />
                      Baixar
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-red-500 hover:text-red-600"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(video.id);
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Modal de Preview */}
      {selectedVideo && (
        <div
          className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50"
          onClick={() => setSelectedVideo(null)}
        >
          <Card className="bg-slate-800 border-slate-700 max-w-2xl w-full">
            <div className="p-6">
              <h2 className="text-2xl font-bold text-white mb-4">Detalhes do Vídeo</h2>

              {selectedVideo.videoUrl && (
                <video
                  src={selectedVideo.videoUrl}
                  controls
                  className="w-full rounded-lg mb-4 bg-slate-900"
                />
              )}

              <div className="space-y-3 mb-6">
                <div>
                  <p className="text-slate-400 text-sm">História</p>
                  <p className="text-white">{selectedVideo.story}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-slate-400 text-sm">Voz</p>
                    <p className="text-white">{getVoiceLabel(selectedVideo.voice)}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Estilo</p>
                    <p className="text-white">{getStyleLabel(selectedVideo.style)}</p>
                  </div>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Data de Criação</p>
                  <p className="text-white">{formatDate(selectedVideo.createdAt)}</p>
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  className="flex-1 bg-pink-600 hover:bg-pink-700"
                  onClick={() => handleDownload(selectedVideo.videoUrl)}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Baixar Vídeo
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setSelectedVideo(null)}
                >
                  Fechar
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
