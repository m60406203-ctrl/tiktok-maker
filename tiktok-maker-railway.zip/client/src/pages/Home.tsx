import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card } from '@/components/ui/card';
import { Loader2, Download, RefreshCw, Zap } from 'lucide-react';

const VOICES = [
  { id: 'francisca', label: 'Francisca - Feminina, jovem e expressiva' },
  { id: 'thalita', label: 'Thalita - Feminina, expressiva e dinamica' },
  { id: 'antonio', label: 'Antonio - Masculina, profissional e clara' },
];

const STYLES = [
  { id: 'viral', label: 'Viral - Dramatico e envolvente' },
  { id: 'story', label: 'Story Time - Narrativo e calmo' },
  { id: 'mystery', label: 'Misterio - Sombrio e tenso' },
];

const EXAMPLES = [
  {
    icon: '👻',
    title: 'Historia de Terror',
    text: 'Uma noite, Maria ouviu passos no corredor vazio.',
  },
  {
    icon: '💔',
    title: 'Drama Romantico',
    text: 'Ele esperou 10 anos para dizer que a amava.',
  },
  {
    icon: '🤯',
    title: 'Fato Incrivel',
    text: 'Voce sabia que o oceano tem mais estrelas que o ceu?',
  },
  {
    icon: '🕵️',
    title: 'Misterio Real',
    text: 'Em 1987, uma cidade inteira desapareceu do mapa.',
  },
];

type GenerationStatus = 'idle' | 'generating' | 'success' | 'error';

interface JobStatus {
  status: string;
  progress?: number;
  stage?: string;
  videoUrl?: string;
  error?: string;
}

export default function Home() {
  const [story, setStory] = useState('');
  const [voice, setVoice] = useState('francisca');
  const [style, setStyle] = useState('viral');
  const [status, setStatus] = useState<GenerationStatus>('idle');
  const [jobId, setJobId] = useState<string | null>(null);
  const [jobStatus, setJobStatus] = useState<JobStatus | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!jobId || status !== 'generating') return;

    const interval = setInterval(async () => {
      try {
        const response = await fetch(`http://localhost:7860/status/${jobId}`);
        const data = await response.json();
        setJobStatus(data);

        if (data.status === 'completed') {
          setVideoUrl(data.videoUrl);
          setStatus('success');
          setJobId(null);
        } else if (data.status === 'error') {
          setError(data.error || 'Erro ao gerar video');
          setStatus('error');
          setJobId(null);
        }
      } catch (err) {
        console.error('Erro ao verificar status:', err);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [jobId, status]);

  const handleGenerate = async () => {
    if (!story.trim()) {
      setError('Por favor, escreva uma historia');
      return;
    }

    if (story.length < 50) {
      setError('A historia deve ter pelo menos 50 caracteres');
      return;
    }

    setStatus('generating');
    setError(null);
    setJobStatus(null);

    try {
      const response = await fetch('http://localhost:7860/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          story: story.trim(),
          voice,
          style,
          pexels_key: 'ktCF8WXXzzudrpbzMjMrUxbOXmZQ8EU2mGtF6ni7lyCudpXQhnBK5eIQ',
        }),
      });

      const data = await response.json();

      if (data.job_id) {
        setJobId(data.job_id);
      } else {
        setError(data.error || 'Erro ao iniciar geracao');
        setStatus('error');
      }
    } catch (err) {
      setError('Erro de conexao com o servidor');
      setStatus('error');
    }
  };

  const handleExample = (example: typeof EXAMPLES[0]) => {
    setStory(example.text);
  };

  const handleReset = () => {
    setStory('');
    setVoice('francisca');
    setStyle('viral');
    setStatus('idle');
    setJobId(null);
    setJobStatus(null);
    setVideoUrl(null);
    setError(null);
  };

  const handleDownload = () => {
    if (videoUrl) {
      const link = document.createElement('a');
      link.href = videoUrl;
      link.download = 'video-tiktok.mp4';
      link.click();
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-border/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-accent to-secondary flex items-center justify-center">
              <Zap className="w-6 h-6 text-accent-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold">TikMaker</h1>
              <p className="text-xs text-muted-foreground">Gerador de Videos Virais</p>
            </div>
          </div>
          <a href="/historico" className="text-sm font-medium text-accent hover:text-accent/80 transition-colors">
            Histórico
          </a>
        </div>
      </header>

      <main className="flex-1 container py-8">
        {status === 'idle' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <div>
                <h2 className="text-2xl font-bold mb-6">Crie seu video viral</h2>

                <div className="space-y-2 mb-6">
                  <label className="text-sm font-medium">Sua historia</label>
                  <Textarea
                    placeholder="Escreva sua historia aqui..."
                    value={story}
                    onChange={(e) => setStory(e.target.value)}
                    className="min-h-40 resize-none"
                  />
                  <div className="text-xs text-muted-foreground text-right">
                    {story.length} / 3000
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Voz</label>
                    <Select value={voice} onValueChange={setVoice}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {VOICES.map((v) => (
                          <SelectItem key={v.id} value={v.id}>
                            {v.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Estilo</label>
                    <Select value={style} onValueChange={setStyle}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {STYLES.map((s) => (
                          <SelectItem key={s.id} value={s.id}>
                            {s.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button
                  onClick={handleGenerate}
                  disabled={!story.trim() || story.length < 50}
                  size="lg"
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                >
                  Gerar Video TikTok Agora
                </Button>

                {error && (
                  <div className="mt-4 p-4 bg-destructive/10 border border-destructive/20 rounded-lg text-sm text-destructive">
                    {error}
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-6">
              <Card className="p-4 bg-card/50 backdrop-blur-sm">
                <h3 className="font-bold mb-4">Dicas para videos virais</h3>
                <ul className="space-y-3 text-sm text-muted-foreground">
                  <li>Comece com um gancho forte</li>
                  <li>Historias de 150-400 palavras</li>
                  <li>Use emocoes intensas</li>
                  <li>Termine com uma reviravolta</li>
                  <li>Palavras especificas ajudam</li>
                </ul>
              </Card>
            </div>
          </div>
        )}

        {status === 'generating' && (
          <div className="flex flex-col items-center justify-center min-h-96 space-y-8">
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-bold">Gerando seu video...</h3>
              <p className="text-muted-foreground">Isso pode levar 1-3 minutos</p>
            </div>

            <div className="flex gap-3 flex-wrap justify-center max-w-2xl">
              {[
                { label: 'Narracao', icon: '🎙️', stage: 'narration' },
                { label: 'Legendas', icon: '💬', stage: 'subtitles' },
                { label: 'Midia', icon: '🖼️', stage: 'media' },
                { label: 'Video', icon: '🎞️', stage: 'video' },
                { label: 'Renderizacao', icon: '✨', stage: 'rendering' },
              ].map((step) => {
                const isActive = jobStatus?.stage === step.stage;
                const stages = ['narration', 'subtitles', 'media', 'video', 'rendering'];
                const currentIdx = jobStatus?.stage ? stages.indexOf(jobStatus.stage) : -1;
                const stepIdx = stages.indexOf(step.stage);
                const isCompleted = currentIdx > stepIdx;
                return (
                  <div
                    key={step.stage}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                      isActive
                        ? 'bg-accent text-accent-foreground animate-pulse'
                        : isCompleted
                        ? 'bg-accent/30 text-accent-foreground'
                        : 'bg-border text-muted-foreground'
                    }`}
                  >
                    {step.icon} {step.label}
                  </div>
                );
              })}
            </div>

            {jobStatus?.progress && (
              <div className="w-full max-w-md space-y-2">
                <div className="h-2 bg-border rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-accent to-secondary transition-all duration-500"
                    style={{ width: `${jobStatus.progress}%` }}
                  ></div>
                </div>
                <p className="text-center text-xs text-muted-foreground">{jobStatus.progress}%</p>
              </div>
            )}
          </div>
        )}

        {status === 'success' && videoUrl && (
          <div className="flex flex-col items-center justify-center min-h-96 space-y-6">
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-bold">Video pronto!</h3>
              <p className="text-muted-foreground">1080x1920 - Pronto para TikTok</p>
            </div>

            <div className="flex gap-4">
              <Button
                onClick={handleDownload}
                size="lg"
                className="bg-accent hover:bg-accent/90 text-accent-foreground"
              >
                <Download className="w-4 h-4 mr-2" />
                Baixar MP4
              </Button>
              <Button
                onClick={handleReset}
                size="lg"
                variant="outline"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Criar novo
              </Button>
            </div>
          </div>
        )}

        {status === 'error' && (
          <div className="flex flex-col items-center justify-center min-h-96 space-y-6">
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-bold">Erro ao gerar</h3>
              <p className="text-muted-foreground">{error}</p>
            </div>
            <Button
              onClick={handleReset}
              size="lg"
              variant="outline"
            >
              Tentar novamente
            </Button>
          </div>
        )}
      </main>

      {status === 'idle' && (
        <section className="border-t border-border/50 py-12">
          <div className="container">
            <h2 className="text-2xl font-bold mb-8">Exemplos de historias</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {EXAMPLES.map((example, idx) => (
                <Card
                  key={idx}
                  className="p-4 cursor-pointer hover:border-accent/50 transition-colors group"
                  onClick={() => handleExample(example)}
                >
                  <div className="text-3xl mb-2">{example.icon}</div>
                  <h3 className="font-bold mb-2 group-hover:text-accent transition-colors">
                    {example.title}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-3">
                    {example.text}
                  </p>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      <footer className="border-t border-border/50 py-6 mt-auto">
        <div className="container text-center text-sm text-muted-foreground">
          Feito com amor e IA - TikMaker 2025
        </div>
      </footer>
    </div>
  );
}
